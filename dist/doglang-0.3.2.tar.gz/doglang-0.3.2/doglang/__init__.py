from doglang.main import Interpreter
from doglang.error import Error

__version__ = "0.1.0"
__all__ = ["Interpreter", "Error"]
